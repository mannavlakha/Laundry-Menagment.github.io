<?php
	class laundry_myvariable{
	public $hostnames = "localhost";
	public $username = "root";
	public $passwords = "";
	public $database = "dblaundry";
} ?>