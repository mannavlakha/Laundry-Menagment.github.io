<?php   
class laundry_version_update{

	/* 
    Open a connect to the database.
    Make sure this is called on every page that needs to use the database.
	 */
    public $version="1.0";
    public $conn;

	public function update1_1()
	{
    
  }
}
?>